from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import matplotlib 
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pyspark.sql import Window

spark = SparkSession.builder \
        .master("local[4]") \
        .appName("Q2") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN")

from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.sql import Row

# Q2-A-1)

# Load in ratings data
raw_ratings = spark.read.load('../Data/ratings.csv', format = 'csv', inferSchema = "true", header = "true").cache()
# First sorted data by the timestamp and add a column rank
ratings_rank = raw_ratings.withColumn("rank", F.percent_rank().over(Window.partitionBy().orderBy("timestamp"))).cache()
# Use rank to split data into train and test
# Split 50% for training set
train1 = ratings_rank.where("rank <= .5").drop("rank")
test1 = ratings_rank.where("rank > .5").drop("rank")
# Split 65% for training set
train2 = ratings_rank.where("rank <= .65").drop("rank")
test2 = ratings_rank.where("rank > .65").drop("rank")
# Split 80% for training set
train3 = ratings_rank.where("rank <= .8").drop("rank")
test3 = ratings_rank.where("rank > .8").drop("rank")
# Cache data
train1 = train1.cache()
test1 = test1.cache()
train2 = train2.cache()
test2 = test2.cache()
train3 = train3.cache()
test3 = test3.cache()


# Q2-A-2)
myseed = 200206312

# Training data sizes: 50%

# ALS version 1
# Define model1
als1 = ALS(userCol = "userId", itemCol = "movieId", seed = myseed, coldStartStrategy = "drop")
# Define evaluator
evaluator_rmse = RegressionEvaluator(metricName = "rmse", labelCol = "rating", predictionCol = "prediction")
evaluator_mse = RegressionEvaluator(metricName = "mse", labelCol = "rating", predictionCol = "prediction")
evaluator_mae = RegressionEvaluator(metricName = "mae", labelCol = "rating", predictionCol = "prediction")
# Run model with default rank (which is 10)
model50_1 = als1.fit(train1)

# Evaluation
predictions50_1 = model50_1.transform(test1)
# RMSE
rmse50_1 = evaluator_rmse.evaluate(predictions50_1)
print("================================ Q2-A-2) ================================")
print("=============================== Split 50% ===============================")
print(f"Split 50%, ALS version 1: Root-mean-square error = {rmse50_1}")
# MSE
mse50_1 = evaluator_mse.evaluate(predictions50_1)
print(f"Split 50%, ALS version 1: Mean-square error = {mse50_1}")
# MAE
mae50_1 = evaluator_mae.evaluate(predictions50_1)
print(f"Split 50%, ALS version 1: Mean-absolute error = {mae50_1}")
print("=========================================================================")

# ALS version 2
# Define model2
als2 = ALS(userCol = "userId", itemCol = "movieId", seed = myseed, coldStartStrategy = "drop", rank = 20)
# Run model with rank = 20
model50_2 = als2.fit(train1)
# Evaluation
predictions50_2 = model50_2.transform(test1)
# RMSE
rmse50_2 = evaluator_rmse.evaluate(predictions50_2)
print(f"Split 50%, ALS version 2: Root-mean-square error = {rmse50_2}")
# MSE
mse50_2 = evaluator_mse.evaluate(predictions50_2)
print(f"Split 50%, ALS version 2: Mean-square error = {mse50_2}")
# MAE
mae50_2 = evaluator_mae.evaluate(predictions50_2)
print(f"Split 50%, ALS version 2: Mean-absolute error = {mae50_2}")
print("=========================================================================")

# ALS version 3
# Define model3
als3 = ALS(userCol = "userId", itemCol = "movieId", seed = myseed, coldStartStrategy = "drop", maxIter = 15)
# Run model with maxIter = 15
model50_3 = als3.fit(train1)
# Evaluation
predictions50_3 = model50_3.transform(test1)
# RMSE
rmse50_3 = evaluator_rmse.evaluate(predictions50_3)
print(f"Split 50%, ALS version 3: Root-mean-square error = {rmse50_3}")
# MSE
mse50_3 = evaluator_mse.evaluate(predictions50_3)
print(f"Split 50%, ALS version 3: Mean-square error = {mse50_3}")
# MAE
mae50_3 = evaluator_mae.evaluate(predictions50_3)
print(f"Split 50%, ALS version 3: Mean-absolute error = {mae50_3}")
print("=========================================================================")

# Training data sizes: 65%

# ALS version 1
# Run model with default rank (which is 10)
model65_1 = als1.fit(train2)
# Evaluation
predictions65_1 = model65_1.transform(test2)
# RMSE
rmse65_1 = evaluator_rmse.evaluate(predictions65_1)
print("=============================== Split 65% ===============================")
print(f"Split 65%, ALS version 1: Root-mean-square error = {rmse65_1}")
# MSE
mse65_1 = evaluator_mse.evaluate(predictions65_1)
print(f"Split 65%, ALS version 1: Mean-square error = {mse65_1}")
# MAE
mae65_1 = evaluator_mae.evaluate(predictions65_1)
print(f"Split 65%, ALS version 1: Mean-absolute error = {mae65_1}")
print("=========================================================================")

# ALS version 2
# Run model with rank = 20
model65_2 = als2.fit(train2)
# Evaluation
predictions65_2 = model65_2.transform(test2)
# RMSE
rmse65_2 = evaluator_rmse.evaluate(predictions65_2)
print(f"Split 65%, ALS version 2: Root-mean-square error = {rmse65_2}")
# MSE
mse65_2 = evaluator_mse.evaluate(predictions65_2)
print(f"Split 65%, ALS version 2: Mean-square error = {mse65_2}")
# MAE
mae65_2 = evaluator_mae.evaluate(predictions65_2)
print(f"Split 65%, ALS version 2: Mean-absolute error = {mae65_2}")
print("=========================================================================")

# ALS version 3
# Run model with maxIter = 15
model65_3 = als3.fit(train2)
# Evaluation
predictions65_3 = model65_3.transform(test2)
# RMSE
rmse65_3 = evaluator_rmse.evaluate(predictions65_3)
print(f"Split 65%, ALS version 3: Root-mean-square error = {rmse65_3}")
# MSE
mse65_3 = evaluator_mse.evaluate(predictions65_3)
print(f"Split 65%, ALS version 3: Mean-square error = {mse65_3}")
# MAE
mae65_3 = evaluator_mae.evaluate(predictions65_3)
print(f"Split 65%, ALS version 3: Mean-absolute error = {mae65_3}")
print("=========================================================================")

# Training data sizes: 80%

# ALS version 1
# Run model with default rank (which is 10)
model80_1 = als1.fit(train3)
# Evaluation
predictions80_1 = model80_1.transform(test3)
# RMSE
rmse80_1 = evaluator_rmse.evaluate(predictions80_1)
print("=============================== Split 80% ===============================")
print(f"Split 80%, ALS version 1: Root-mean-square error = {rmse80_1}")
# MSE
mse80_1 = evaluator_mse.evaluate(predictions80_1)
print(f"Split 80%, ALS version 1: Mean-square error = {mse80_1}")
# MAE
mae80_1 = evaluator_mae.evaluate(predictions80_1)
print(f"Split 80%, ALS version 1: Mean-absolute error = {mae80_1}")
print("=========================================================================")

# ALS version 2
# Run model with rank = 20
model80_2 = als2.fit(train3)
# Evaluation
predictions80_2 = model80_2.transform(test3)
# RMSE
rmse80_2 = evaluator_rmse.evaluate(predictions80_2)
print(f"Split 80%, ALS version 2: Root-mean-square error = {rmse80_2}")
# MSE
mse80_2 = evaluator_mse.evaluate(predictions80_2)
print(f"Split 80%, ALS version 2: Mean-square error = {mse80_2}")
# MAE
mae80_2 = evaluator_mae.evaluate(predictions80_2)
print(f"Split 80%, ALS version 2: Mean-absolute error = {mae80_2}")
print("=========================================================================")

# ALS version 3
# Run model with maxIter = 15
model80_3 = als3.fit(train3)
# Evaluation
predictions80_3 = model80_3.transform(test3)
# RMSE
rmse80_3 = evaluator_rmse.evaluate(predictions80_3)
print(f"Split 80%, ALS version 3: Root-mean-square error = {rmse80_3}")
# MSE
mse80_3 = evaluator_mse.evaluate(predictions80_3)
print(f"Split 80%, ALS version 3: Mean-square error = {mse80_3}")
# MAE
mae80_3 = evaluator_mae.evaluate(predictions80_3)
print(f"Split 80%, ALS version 3: Mean-absolute error = {mae80_3}")
print("=========================================================================")


# Q2-B-1)
from pyspark.ml.clustering import KMeans
from pyspark.ml.clustering import KMeansModel
from pyspark.ml.evaluation import ClusteringEvaluator

# Training data sizes: 50%
# Get user factors
UserFactors_50 = model50_1.userFactors
# Use k-means(k = 20) to cluster the user factors
kmeans_50 = KMeans().setK(20).setSeed(myseed)
model_50 = kmeans_50.fit(UserFactors_50)
predictions_50 = model_50.transform(UserFactors_50)

# Count size of the top three largest user clusters
clusters_size_50 = predictions_50.select('prediction').groupBy('prediction').count().sort('count', ascending=False)
print("============================= Q2-B-1) =============================")
print("===================================================================")
print("Size of the top three largest user clusters of 50% training data:")
clusters_size_50.show(3, False)


# Training data sizes: 65%
# Get user factors
UserFactors_65 = model65_1.userFactors
# Use k-means(k = 20) to cluster the user factors
kmeans_65 = KMeans().setK(20).setSeed(myseed)
model_65 = kmeans_65.fit(UserFactors_65)
predictions_65 = model_65.transform(UserFactors_65)
# Count size of the top three largest user clusters
clusters_size_65 = predictions_65.select('prediction').groupBy('prediction').count().sort('count', ascending=False)
print("===================================================================")
print("Size of the top three largest user clusters of 65% training data:")
clusters_size_65.show(3, False)


# Training data sizes: 80%
# Get user factors
UserFactors_80 = model80_1.userFactors
# Use k-means(k = 20) to cluster the user factors
kmeans_80 = KMeans().setK(20).setSeed(myseed)
model_80 = kmeans_80.fit(UserFactors_80)
predictions_80 = model_80.transform(UserFactors_80)
# Count size of the top three largest user clusters
clusters_size_80 = predictions_80.select('prediction').groupBy('prediction').count().sort('count', ascending=False)
print("===================================================================")
print("Size of the top three largest user clusters of 80% training data:")
clusters_size_80.show(3, False)


# Q2-B-2)

# Load in ratings data
movies = spark.read.load('../Data/movies.csv', format = 'csv', inferSchema = "true", header = "true").cache()

# Training data sizes: 50%

# Get all userId of the largest cluster
largest_cluster_50 = predictions_50.filter('prediction == 4')
# Rename 'id' column to 'userId'
largest_cluster_50 = largest_cluster_50.selectExpr("id as userId", "features as features", "prediction as prediction")
# Use left-semi join to filter training set to get movieId, then filter them with the condition (rating >= 4.0) to get target movieIds 
get_movieId_50_train = train1.join(largest_cluster_50, 'userId', how = 'left_semi')
get_movieId_50_train = get_movieId_50_train.filter('rating >= 4.0')
#get_movieId_50_train.show(30, False)
#get_movieId_50_train.describe().show()
# Join movies.csv and 'get_movieId_50_train' to match genres for all movieIds
movieId_50_train_genres = get_movieId_50_train.join(movies, 'movieId', how = 'left').orderBy('userId', ascending = True)
# Find the top five genres.
movieId_50_train_top5 = movieId_50_train_genres.withColumn('word', F.explode(F.split(F.col('genres'), '\|'))).groupBy('word').count().sort('count', ascending=False)
print("================================================= Q2-B-2) ==================================================")
print("The top five genres among movies watched by all users in the largest user cluster (50% split, training set):")
movieId_50_train_top5.show(5, False)
# Use left-semi join to filter testing set to get movieId, then filter them with the condition (rating >= 4.0) to get target movieIds 
get_movieId_50_test = test1.join(largest_cluster_50, 'userId', how = 'left_semi')
get_movieId_50_test = get_movieId_50_test.filter('rating >= 4.0')
#get_movieId_50_test.show(30, False)
#get_movieId_50_test.describe().show()
# Join movies.csv and 'get_movieId_50_test' to match genres for all movieIds
movieId_50_test_genres = get_movieId_50_test.join(movies, 'movieId', how = 'left').orderBy('userId', ascending = True)
# Find the top five genres.
movieId_50_test_top5 = movieId_50_test_genres.withColumn('word', F.explode(F.split(F.col('genres'), '\|'))).groupBy('word').count().sort('count', ascending=False)
print("===========================================================================================================")
print("The top five genres among movies watched by all users in the largest user cluster (50% split, testing set):")
movieId_50_test_top5.show(5, False)

# Training data sizes: 65%

# Get all userId of the largest cluster
largest_cluster_65 = predictions_65.filter('prediction == 2')
# Rename 'id' column to 'userId'
largest_cluster_65 = largest_cluster_65.selectExpr("id as userId", "features as features", "prediction as prediction")
# Use left-semi join to filter training set to get movieId, then filter them with the condition (rating >= 4.0) to get target movieIds 
get_movieId_65_train = train2.join(largest_cluster_65, 'userId', how = 'left_semi')
get_movieId_65_train = get_movieId_65_train.filter('rating >= 4.0')
#get_movieId_65_train.show(30, False)
#get_movieId_65_train.describe().show()
# Join movies.csv and 'get_movieId_65_train' to match genres for all movieIds
movieId_65_train_genres = get_movieId_65_train.join(movies, 'movieId', how = 'left').orderBy('userId', ascending = True)
# Find the top five genres.
movieId_65_train_top5 = movieId_65_train_genres.withColumn('word', F.explode(F.split(F.col('genres'), '\|'))).groupBy('word').count().sort('count', ascending=False)
print("============================================================================================================")
print("The top five genres among movies watched by all users in the largest user cluster (65% split, training set):")
movieId_65_train_top5.show(5, False)
# Use left-semi join to filter testing set to get movieId, then filter them with the condition (rating >= 4.0) to get target movieIds 
get_movieId_65_test = test2.join(largest_cluster_65, 'userId', how = 'left_semi')
get_movieId_65_test = get_movieId_65_test.filter('rating >= 4.0')
#get_movieId_65_test.show(30, False)
#get_movieId_65_test.describe().show()
# Join movies.csv and 'get_movieId_65_test' to match genres for all movieIds
movieId_65_test_genres = get_movieId_65_test.join(movies, 'movieId', how = 'left').orderBy('userId', ascending = True)
# Find the top five genres.
movieId_65_test_top5 = movieId_65_test_genres.withColumn('word', F.explode(F.split(F.col('genres'), '\|'))).groupBy('word').count().sort('count', ascending=False)
print("===========================================================================================================")
print("The top five genres among movies watched by all users in the largest user cluster (65% split, testing set):")
movieId_65_test_top5.show(5, False)

# Training data sizes: 80%

# Get all userId of the largest cluster
largest_cluster_80 = predictions_80.filter('prediction == 8')
# Rename 'id' column to 'userId'
largest_cluster_80 = largest_cluster_80.selectExpr("id as userId", "features as features", "prediction as prediction")
# Use left-semi join to filter training set to get movieId, then filter them with the condition (rating >= 4.0) to get target movieIds 
get_movieId_80_train = train3.join(largest_cluster_80, 'userId', how = 'left_semi')
get_movieId_80_train = get_movieId_80_train.filter('rating >= 4.0')
#get_movieId_80_train.show(30, False)
#get_movieId_80_train.describe().show()
# Join movies.csv and 'get_movieId_80_train' to match genres for all movieIds
movieId_80_train_genres = get_movieId_80_train.join(movies, 'movieId', how = 'left').orderBy('userId', ascending = True)
# Find the top five genres.
movieId_80_train_top5 = movieId_80_train_genres.withColumn('word', F.explode(F.split(F.col('genres'), '\|'))).groupBy('word').count().sort('count', ascending=False)
print("============================================================================================================")
print("The top five genres among movies watched by all users in the largest user cluster (80% split, training set):")
movieId_80_train_top5.show(5, False)
# Use left-semi join to filter testing set to get movieId, then filter them with the condition (rating >= 4.0) to get target movieIds 
get_movieId_80_test = test3.join(largest_cluster_80, 'userId', how = 'left_semi')
get_movieId_80_test = get_movieId_80_test.filter('rating >= 4.0')
#get_movieId_80_test.show(30, False)
#get_movieId_80_test.describe().show()
# Join movies.csv and 'get_movieId_80_test' to match genres for all movieIds
movieId_80_test_genres = get_movieId_80_test.join(movies, 'movieId', how = 'left').orderBy('userId', ascending = True)
# Find the top five genres.
movieId_80_test_top5 = movieId_80_test_genres.withColumn('word', F.explode(F.split(F.col('genres'), '\|'))).groupBy('word').count().sort('count', ascending=False)
print("===========================================================================================================")
print("The top five genres among movies watched by all users in the largest user cluster (80% split, testing set):")
movieId_80_test_top5.show(5, False)