from pyspark.sql import SparkSession
from pyspark.sql import Row
import pyspark.sql.functions as F
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import tldextract
import seaborn as sns
import numpy as np

spark = SparkSession.builder \
        .master("local[4]") \
        .appName("Q1") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN") 

logFile = spark.read.text("../Data/NASA_access_log_Jul95.gz").cache()   
#logFile.show(20, False)

# split into 5 columns using regex and split
data = logFile.withColumn('host', F.regexp_extract('value', '^(.*) - -.*', 1)) \
                .withColumn('timestamp', F.regexp_extract('value', '.* - - \[(.*)\].*',1)) \
                .withColumn('request', F.regexp_extract('value', '.*\"(.*)\".*',1)) \
                .withColumn('HTTP reply code', F.split('value', ' ').getItem(F.size(F.split('value', ' ')) -2).cast("int")) \
                .withColumn('bytes in the reply', F.split('value', ' ').getItem(F.size(F.split('value', ' ')) - 1).cast("int")).drop("value").cache()
#data.show(20,False)

# Q1-A
# 1)
q1A1_out = data.filter(logFile.value.contains(".ac.jp")).cache() 
#q1A1_out.show(20, False)
print("==================== Question 1A-1 ====================")
print(f"There are {q1A1_out.count()} requests are from .ac.jp.")
print("=======================================================")
# 2)
q1A2_out = data.filter(logFile.value.contains(".ac.uk")).cache() 
#q1A2_out.show(20, False)
print("==================== Question 1A-2 ====================")
print(f"There are {q1A2_out.count()} requests are from .ac.uk.")
print("=======================================================")
# 3)
q1A3_out = data.filter(logFile.value.contains(".edu")).cache() 
#q1A3_out.show(20, False)
print("==================== Question 1A-3 ====================")
print(f"There are {q1A3_out.count()} requests are from .edu.")
print("=======================================================")
# Visualise results using one bar graph
plt.clf()
fig, ax = plt.subplots(1,1, figsize =(8,6))
x = ['.ac.jp', '.ac.uk', '.edu']
y = [q1A1_out.count(), q1A2_out.count(), q1A3_out.count()]
ax.bar(x, y, color='blue')
for i, v in enumerate(y):
    ax.text(i - 0.15, v + 0.07, str(v))
plt.title('Total number of requests of universities in three countries', fontsize = 18)
plt.xlabel('Country', fontsize = 12)
plt.ylabel('Total number of requests', fontsize = 12)
plt.savefig("../Output/Q1-A.png", bbox_inches='tight')
plt.clf()


# Q1-B
# 1)

# Japan
# Select 'host' column
jp_host = q1A1_out.select('host')
# Collect all items of 'host' column in an array
jp_host_row = jp_host.rdd.map(lambda jp_host:jp_host.host).collect()
# Create a empty list jp_domain
jp_domain = list()
# Use 'tldextract' package to get domain of each host and append to the a list
for h in jp_host_row:
    jp_domain.append(tldextract.extract(str(h)).registered_domain)
# Convert list to dataframe
rdd_jp_domain = sc.parallelize(jp_domain)
row = Row("domain")
jp_domain_df = rdd_jp_domain.map(row).toDF()
# Find the top 9 most frequent universities in Japan
print("====================== Question 1B-1 ======================")
print("====== The top 9 most frequent universities in Japan ======")
jp_domain_df.groupby('domain').count().sort('count', ascending=False).show(9, False)

# UK
# Select 'host' column
uk_host = q1A2_out.select('host')
# Collect all items of 'host' column in an array
uk_host_row = uk_host.rdd.map(lambda uk_host:uk_host.host).collect()
# Create a empty list uk_domain
uk_domain = list()
# Use 'tldextract' package to get domain of each host and append to the a list
for h in uk_host_row:
    uk_domain.append(tldextract.extract(h).registered_domain)
# Convert list to dataframe
rdd_uk_domain = sc.parallelize(uk_domain)
row = Row("domain")
uk_domain_df = rdd_uk_domain.map(row).toDF()
# Find the top 9 most frequent universities in UK
print("====== The top 9 most frequent universities in UK ======")
uk_domain_df.groupby('domain').count().sort('count', ascending=False).show(9, False)

# US
# Select 'host' column
us_host = q1A3_out.select('host')
# Collect all items of 'host' column in an array
us_host_row = us_host.rdd.map(lambda us_host:us_host.host).collect()
# Create a empty list us_domain
us_domain = list()
# Use 'tldextract' package to get domain of each host and append to the a list
for h in us_host_row:
    us_domain.append(tldextract.extract(h).registered_domain)
# Convert list to dataframe
rdd_us_domain = sc.parallelize(us_domain)
row = Row("domain")
us_domain_df = rdd_us_domain.map(row).toDF()
# Find the top 9 most frequent universities in US
print("====== The top 9 most frequent universities in US ======")
us_domain_df.groupby('domain').count().sort('count', ascending=False).show(9, False)
print("========================================================")

# 2)

# Japan
# Produce pie chart
fig, ax = plt.subplots(1,1, figsize =(8,6))
labels_jp = ['tohoku.ac.jp', 'kyoto-u.ac.jp', 'nagoya-u.ac.jp', 'u-tokyo.ac.jp', 'osaka-u.ac.jp', 'shizuoka.ac.jp', 'ritsumei.ac.jp', 'keio.ac.jp', 'waseda.ac.jp', 'rest of uni']
sizes_jp = [824, 703, 692, 689, 527, 472, 426, 346, 337, 8061]
pie_jp = ax.pie(sizes_jp, shadow=True, autopct='%1.2f%%', startangle=90, pctdistance=0.93)
ax.legend(pie_jp[0], labels_jp, loc="upper right")
plt.title('Percentage of requests in Japan', fontsize = 18)
plt.axis('equal')
plt.tight_layout()
plt.savefig("../Output/Q1-B2-JP.png", bbox_inches='tight')

# UK
# Produce pie chart
fig, ax = plt.subplots(1,1, figsize =(8,6))
labels_uk = ['hensa.ac.uk', 'rl.ac.uk', 'ucl.ac.uk', 'man.ac.uk', 'ic.ac.uk', 'soton.ac.uk', 'bham.ac.uk', 'shef.ac.uk', 'le.ac.uk', 'rest of uni']
sizes_uk = [4257, 1158, 1036, 921, 851, 808, 629, 623, 616, 14115]
pie_uk = ax.pie(sizes_uk, shadow=True, autopct='%1.2f%%', startangle=90, pctdistance=0.93)
ax.legend(pie_uk[0], labels_uk, loc="upper right")
plt.title('Percentage of requests in UK', fontsize = 18)
plt.axis('equal')
plt.tight_layout()
plt.savefig("../Output/Q1-B2-UK.png", bbox_inches='tight')

# US
# Produce pie chart
fig, ax = plt.subplots(1,1, figsize =(8,6))
labels_us = ['tamu.edu', 'berkeley.edu', 'fsu.edu', 'umn.edu', 'mit.edu', 'washington.edu', 'uiuc.edu', 'utexas.edu', 'cmu.edu', 'rest of uni']
sizes_us = [6062, 5439, 4418, 4404, 3966, 3893, 3750, 3665, 3244, 188653]
pie_us = ax.pie(sizes_us, shadow=True, autopct='%1.2f%%', startangle=90, pctdistance=0.93)
ax.legend(pie_us[0], labels_us, loc="upper right")
plt.title('Percentage of requests in US', fontsize = 18)
plt.axis('equal')
plt.tight_layout()
plt.savefig("../Output/Q1-B2-US.png", bbox_inches='tight')


# Q1-C

# Japan

# Get imformation of the most frequent university in Japan
q1C1_out = data.filter(logFile.value.contains("tohoku.ac.jp")).cache()
# Transform the 'timestamp' column to standard form
q1C1_timestamp = q1C1_out.select('timestamp')
split_col = F.split(q1C1_timestamp['timestamp'], '-')
q1C1_timestamp = q1C1_timestamp.withColumn('input_timestamp', split_col.getItem(0)).select('input_timestamp')
q1C1_timestamp = q1C1_timestamp.withColumn("date_timestamp", F.to_timestamp("input_timestamp", "dd/MMM/yyyy:HH:mm:ss "))
q1C1_timestamp = q1C1_timestamp.select('date_timestamp')
#q1C1_timestamp.show(10, False)

# Split date and time
split_col1 = F.split(q1C1_timestamp['date_timestamp'], ' ')
q1C1_date = q1C1_timestamp.withColumn('date', split_col1.getItem(0)).select('date')
q1C1_time = q1C1_timestamp.withColumn('time', split_col1.getItem(1)).select('time')
# In time column, only contain hour, then merge hour column to date dataframe 
split_col2 = F.split(q1C1_time['time'], ':')
q1C1_hour = q1C1_time.withColumn('hour', split_col2.getItem(0)).select('hour')
# Merge date and hour dataframes
df1 = q1C1_date.withColumn("id", F.monotonically_increasing_id())
df2 = q1C1_hour.withColumn("id", F.monotonically_increasing_id())
q1C1_date_hour = df1.join(df2, 'id', how = 'outer').drop('id').orderBy('date', 'hour',  ascending = True)
#q1C1_date_hour.show(50, False)
# Count the visit number in every hour for each day.
q1C1_count = q1C1_date_hour.groupBy('date', 'hour').agg(F.count('hour')).orderBy('date', 'hour',  ascending = True)
# Print the result
#print("=== Count of visit number from 'tohoku.ac.jp' in every hour for each day ===")
#q1C1_count.show(50)
#print("============================================================================")
# Transform dataframe using pivot to get the array for heatmap
q1C1_count_pivot = q1C1_count.groupBy('hour').pivot('date').sum('count(hour)').fillna(0).orderBy('hour',  ascending = True)
#q1C1_count_pivot.show(50, False)
q1C1_count_pivot = q1C1_count_pivot.drop('hour')
q1C1_count_array = np.array(q1C1_count_pivot.select('*').collect())
# Print heatmap
plt.clf()
xticks = [1, 3, 5, 6, 7, 9, 10, 11, 12, 13, 14, 17, 18, 19, 20, 21, 22, 25, 26, 27, 28]
yticks = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 22, 23]
ax = sns.heatmap(q1C1_count_array, linewidth=0.5)
plt.title('Heatmap of the number of visits from tohoku.ac.jp', fontsize = 18)
plt.xlabel('Day', fontsize = 12)
plt.ylabel('Hour of visit', fontsize = 12)
ax.set_xticks(np.arange(0.5,21.5,1))
ax.set_xticklabels(xticks)
ax.set_yticks(np.arange(0.5,21.5,1))
ax.set_yticklabels(yticks)
plt.savefig("../Output/Q1-C-JP.png", bbox_inches='tight')
plt.clf()

# UK

# Get imformation of the most frequent university in UK
q1C2_out = data.filter(logFile.value.contains("hensa.ac.uk")).cache()
# Transform the 'timestamp' column to standard form
q1C2_timestamp = q1C2_out.select('timestamp')
split_col = F.split(q1C2_timestamp['timestamp'], '-')
q1C2_timestamp = q1C2_timestamp.withColumn('input_timestamp', split_col.getItem(0)).select('input_timestamp')
q1C2_timestamp = q1C2_timestamp.withColumn("date_timestamp", F.to_timestamp("input_timestamp", "dd/MMM/yyyy:HH:mm:ss "))
q1C2_timestamp = q1C2_timestamp.select('date_timestamp')
#q1C2_timestamp.show(10, False)

# Split date and time
split_col1 = F.split(q1C2_timestamp['date_timestamp'], ' ')
q1C2_date = q1C2_timestamp.withColumn('date', split_col1.getItem(0)).select('date')
q1C2_time = q1C2_timestamp.withColumn('time', split_col1.getItem(1)).select('time')
# In time column, only contain hour, then merge hour column to date dataframe 
split_col2 = F.split(q1C2_time['time'], ':')
q1C2_hour = q1C2_time.withColumn('hour', split_col2.getItem(0)).select('hour')
# Merge date and hour dataframes
df1 = q1C2_date.withColumn("id", F.monotonically_increasing_id())
df2 = q1C2_hour.withColumn("id", F.monotonically_increasing_id())
q1C2_date_hour = df1.join(df2, 'id', how = 'outer').drop('id').orderBy('date', 'hour',  ascending = True)
#q1C2_date_hour.show(50, False)
# Count the visit number in every hour for each day.
q1C2_count = q1C2_date_hour.groupBy('date', 'hour').agg(F.count('hour')).orderBy('date', 'hour',  ascending = True)
# Print the result
#print("=== Count of visit number from 'hensa.ac.uk' in every hour for each day ===")
#q1C2_count.show(1000)
#print("============================================================================")
# Transform dataframe using pivot to get the array for heatmap
q1C2_count_pivot = q1C2_count.groupBy('hour').pivot('date').sum('count(hour)').fillna(0).orderBy('hour',  ascending = True)
#q1C2_count_pivot.show(50, False)
q1C2_count_pivot = q1C2_count_pivot.drop('hour')
q1C2_count_array = np.array(q1C2_count_pivot.select('*').collect())
# Print heatmap
plt.clf()
xticks = np.arange(1,29,2)
yticks = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
ax = sns.heatmap(q1C2_count_array, linewidth=0.5)
plt.title('Heatmap of the number of visits from hensa.ac.uk', fontsize = 18)
plt.xlabel('Day', fontsize = 12)
plt.ylabel('Hour of visit', fontsize = 12)
ax.set_xticks(np.arange(0.5,28.5,2))
ax.set_xticklabels(xticks)
ax.set_yticks(np.arange(0.5,22.5,1))
ax.set_yticklabels(yticks)
plt.savefig("../Output/Q1-C-UK.png", bbox_inches='tight')
plt.clf()

# US

# Get imformation of the most frequent university in US
q1C3_out = data.filter(logFile.value.contains("tamu.edu")).cache()
# Transform the 'timestamp' column to standard form
q1C3_timestamp = q1C3_out.select('timestamp')
split_col = F.split(q1C3_timestamp['timestamp'], '-')
q1C3_timestamp = q1C3_timestamp.withColumn('input_timestamp', split_col.getItem(0)).select('input_timestamp')
q1C3_timestamp = q1C3_timestamp.withColumn("date_timestamp", F.to_timestamp("input_timestamp", "dd/MMM/yyyy:HH:mm:ss "))
q1C3_timestamp = q1C3_timestamp.select('date_timestamp')
#q1C3_timestamp.show(10, False)

# Split date and time
split_col1 = F.split(q1C3_timestamp['date_timestamp'], ' ')
q1C3_date = q1C3_timestamp.withColumn('date', split_col1.getItem(0)).select('date')
q1C3_time = q1C3_timestamp.withColumn('time', split_col1.getItem(1)).select('time')
# In time column, only contain hour, then merge hour column to date dataframe 
split_col2 = F.split(q1C3_time['time'], ':')
q1C3_hour = q1C3_time.withColumn('hour', split_col2.getItem(0)).select('hour')
# Merge date and hour dataframes
df1 = q1C3_date.withColumn("id", F.monotonically_increasing_id())
df2 = q1C3_hour.withColumn("id", F.monotonically_increasing_id())
q1C3_date_hour = df1.join(df2, 'id', how = 'outer').drop('id').orderBy('date', 'hour',  ascending = True)
#q1C3_date_hour.show(50, False)
# Count the visit number in every hour for each day.
q1C3_count = q1C3_date_hour.groupBy('date', 'hour').agg(F.count('hour')).orderBy('date', 'hour',  ascending = True)
# Print the result
#print("=== Count of visit number from 'tamu.edu' in every hour for each day ===")
#q1C3_count.show(1000)
#print("============================================================================")
# Transform dataframe using pivot to get the array for heatmap
q1C3_count_pivot = q1C3_count.groupBy('hour').pivot('date').sum('count(hour)').fillna(0).orderBy('hour',  ascending = True)
#q1C3_count_pivot.show(50, False)
q1C3_count_pivot = q1C3_count_pivot.drop('hour')
q1C3_count_array = np.array(q1C3_count_pivot.select('*').collect())
# Print heatmap
plt.clf()
xticks = np.arange(1,29,2)
yticks = [0, 1, 2, 3, 4, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
ax = sns.heatmap(q1C3_count_array, linewidth=0.5)
plt.title('Heatmap of the number of visits from tamu.edu', fontsize = 18)
plt.xlabel('Day', fontsize = 12)
plt.ylabel('Hour of visit', fontsize = 12)
ax.set_xticks(np.arange(0.5,28.5,2))
ax.set_xticklabels(xticks)
ax.set_yticks(np.arange(0.5,22.5,1))
ax.set_yticklabels(yticks)
plt.savefig("../Output/Q1-C-US.png", bbox_inches='tight')
plt.clf()

