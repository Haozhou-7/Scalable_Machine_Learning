from pyspark.sql import SparkSession
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.functions import when, col
from pyspark.sql.types import StringType
from pyspark.sql.functions import col
from pyspark.ml.feature import VectorAssembler
from pyspark.ml import Pipeline
from datetime import datetime
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml.regression import LinearRegression, GeneralizedLinearRegression
from pyspark.ml.evaluation import RegressionEvaluator, MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

spark = SparkSession.builder \
        .master("local[5]") \
        .appName("AS2Q2_2") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN") 

# Load train and test data.
train = spark.read.parquet('../Data/trainset_final.parquet')
test = spark.read.parquet('../Data/testset_final.parquet')
trainset = train.cache()
testset = test.cache()

# Add one column of new labels 0/1 for classification.    
trainset = trainset.withColumn("newlabels", when(col("labels") != 0, 1).otherwise(0))
testset = testset.withColumn("newlabels", when(col("labels") != 0, 1).otherwise(0))

# Use the VectorAssembler tool to concatenate all the features in a vector
vecAssembler = VectorAssembler(inputCols = trainset.schema.names[:-2], outputCol = 'features') 

# Evaluator for both the crossvalidation, and later for checking accuracy
evaluator1 = RegressionEvaluator(labelCol='labels', predictionCol='prediction', metricName='mae')
evaluator2 = RegressionEvaluator(labelCol='labels', predictionCol='prediction', metricName='mse')
evaluator3 = MulticlassClassificationEvaluator(labelCol='newlabels', predictionCol='prediction', metricName='accuracy')
      
# Apply Decision Tree Classifier over the dataset, combine stages into pipeline
dt = DecisionTreeClassifier(labelCol="newlabels", featuresCol="features", maxDepth=25, maxBins=16, impurity='gini')
stages = [vecAssembler, dt]
pipeline = Pipeline(stages=stages)

# Record the time before training model
t1 = datetime.now()
dtModel = pipeline.fit(trainset)
# Record the time after training model
t2 = datetime.now()
prediction = dtModel.transform(trainset)
accuracy = evaluator3.evaluate(prediction)
print("Accuracy for dt model = %g " % accuracy)
# Calculate training time
delta = t2 - t1
print("The training time of dt model is:", delta.total_seconds(),"seconds")

# If the claim was different from zero, train a Gamma regressor (a GLM) to predict the value of the claim.
# Keep features and predicted labels and then transform these labels to original claim amount for regression later.
glmtrainset = prediction.select([c for c in prediction.columns if c not in {'newlabels', 'features', 'rawPrediction', 'probability'}])
glmtrainset = glmtrainset.where("prediction == 1").drop("prediction")
# Make all labels positive for GLM training.
glmtrainset = glmtrainset.withColumn("positivelabels", glmtrainset.labels+1).drop("labels")
glmtrainset = glmtrainset.withColumnRenamed('positivelabels', 'labels')
# Use the VectorAssembler tool to concatenate all the features in a vector
vecAssembler = VectorAssembler(inputCols = glmtrainset.schema.names[:-1], outputCol = 'features') 
      
# Apply GLM over the subset of the dataset, combine stages into pipeline
glm = GeneralizedLinearRegression(labelCol="labels", featuresCol="features", family="gamma", regParam=0.01, link = 'log')
stages = [vecAssembler, glm]
pipeline = Pipeline(stages=stages)

# Record the time before training model
t1 = datetime.now()
glmModel = pipeline.fit(glmtrainset)
# Record the time after training model
t2 = datetime.now()
# Get predicted claim amount of trainset.
prediction = glmModel.transform(glmtrainset)
mae = evaluator1.evaluate(prediction)
mse = evaluator2.evaluate(prediction)
print("Mean absolute error for glm model = %g " % mae)
print("Mean squared error for glm model = %g " % mse)
# Calculate training time
delta = t2 - t1
print("The training time of glm model is:", delta.total_seconds(),"seconds")

# After training our tandem model, use it on testset.
# First, use binary classifier on testset.
prediction_testset = dtModel.transform(testset)
# If the claim was different from zero, train a Gamma regressor (a GLM) to predict the value of the claim.
glmtestset = prediction_testset.select([c for c in prediction_testset.columns if c not in {'newlabels', 'features', 'rawPrediction', 'probability'}])
glmtestset = glmtestset.where("prediction == 1").drop("prediction")
# Make all labels positive for GLM training.
glmtestset = glmtestset.withColumn("positivelabels", glmtestset.labels+1).drop("labels")
glmtestset = glmtestset.withColumnRenamed('positivelabels', 'labels')
# Get predicted claim amount of the claim that was different from zero after classification.
prediction_glm = glmModel.transform(glmtestset)
# Get dataset that is equal to zero after classification.
prediction_0 = prediction_testset.select([c for c in prediction_testset.columns if c not in {'newlabels', 'rawPrediction', 'probability'}])
prediction_0 = prediction_0.where("prediction == 0")
# Binding two dataset
prediction_all = prediction_glm.union(prediction_0)
mae = evaluator1.evaluate(prediction_all)
mse = evaluator2.evaluate(prediction_all)
print("Mean absolute error for tandem model = %g " % mae)
print("Mean squared error for tandem model = %g " % mse)



