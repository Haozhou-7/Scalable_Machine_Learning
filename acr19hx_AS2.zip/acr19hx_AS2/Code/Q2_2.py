from pyspark.sql import SparkSession
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import col
from pyspark.ml.feature import VectorAssembler
from pyspark.ml import Pipeline
from datetime import datetime
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

spark = SparkSession.builder \
        .master("local[5]") \
        .appName("AS2Q2_2") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN") 

# Load train and test data.
trainset = spark.read.parquet('../Data/trainset_final.parquet')
testset = spark.read.parquet('../Data/testset_final.parquet')

# Use the VectorAssembler tool to concatenate all the features in a vector
vecAssembler = VectorAssembler(inputCols = trainset.schema.names[:-1], outputCol = 'features') 
vecTrainingData = vecAssembler.transform(trainset)
#vecTrainingData.select("features", "labels").show(5)
# Evaluator for both the crossvalidation, and later for checking accuracy
evaluator1 = RegressionEvaluator(labelCol='labels', predictionCol='prediction', metricName='mae')
evaluator2 = RegressionEvaluator(labelCol='labels', predictionCol='prediction', metricName='mse')
      
# Apply Linear regression over the subset of the dataset, combine stages into pipeline
lr = LinearRegression(labelCol="labels", featuresCol="features")
stages = [vecAssembler, lr]
pipeline = Pipeline(stages=stages)

# Record the time before training model
t1 = datetime.now()
lrModel = pipeline.fit(trainset)
# Record the time after training model
t2 = datetime.now()
prediction = lrModel.transform(testset)
mae = evaluator1.evaluate(prediction)
mse = evaluator2.evaluate(prediction)
print("Mean absolute error for lr model = %g " % mae)
print("Mean squared error for lr model = %g " % mse)
# Calculate training time
delta = t2 - t1
print("The training time of lr model is:", delta.total_seconds(),"seconds")