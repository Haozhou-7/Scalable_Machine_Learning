from pyspark.sql import SparkSession
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import col
from pyspark.ml.feature import VectorAssembler
from pyspark.ml import Pipeline
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.ml.classification import RandomForestClassifier, GBTClassifier, MultilayerPerceptronClassifier
import json
from datetime import datetime



spark = SparkSession.builder \
        .master("local[5]") \
        .appName("AS2Q1_2and3") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN") 

RawData = spark.read.text("../Data/HIGGS.csv.gz").cache() 

split_col = F.split(RawData['value'], ',')
HiggsData = RawData.withColumn('lepton_pT', split_col.getItem(1)) \
                     .withColumn('lepton_eta', split_col.getItem(2)) \
                     .withColumn('lepton_phi', split_col.getItem(3)) \
                     .withColumn('missing_energy_magnitude', split_col.getItem(4)) \
                     .withColumn('missing_energy_phi', split_col.getItem(5)) \
                     .withColumn('jet_1_pt', split_col.getItem(6)) \
                     .withColumn('jet_1_eta', split_col.getItem(7)) \
                     .withColumn('jet_1_phi', split_col.getItem(8)) \
                     .withColumn('jet_1_b-tag', split_col.getItem(9)) \
                     .withColumn('jet_2_pt', split_col.getItem(10)) \
                     .withColumn('jet_2_eta', split_col.getItem(11)) \
                     .withColumn('jet_2_phi', split_col.getItem(12)) \
                     .withColumn('jet_2_b-tag', split_col.getItem(13)) \
                     .withColumn('jet_3_pt', split_col.getItem(14)) \
                     .withColumn('jet_3_eta', split_col.getItem(15)) \
                     .withColumn('jet_3_phi', split_col.getItem(16)) \
                     .withColumn('jet_3_b-tag', split_col.getItem(17)) \
                     .withColumn('jet_4_pt', split_col.getItem(18)) \
                     .withColumn('jet_4_eta', split_col.getItem(19)) \
                     .withColumn('jet_4_phi', split_col.getItem(20)) \
                     .withColumn('jet_4_b-tag', split_col.getItem(21)) \
                     .withColumn('m_jj', split_col.getItem(22)) \
                     .withColumn('m_jjj', split_col.getItem(23)) \
                     .withColumn('m_lv', split_col.getItem(24)) \
                     .withColumn('m_jlv', split_col.getItem(25)) \
                     .withColumn('m_bb', split_col.getItem(26)) \
                     .withColumn('m_wbb', split_col.getItem(27)) \
                     .withColumn('m_wwbb', split_col.getItem(28)) \
                     .withColumn('labels', split_col.getItem(0)).drop("value").cache()

HiggsData.printSchema()
# Use the withColumn method for the dataframe to cast() each column to Double.
StringColumns = [x.name for x in HiggsData.schema.fields if x.dataType == StringType()]
for c in StringColumns:
    HiggsData = HiggsData.withColumn(c, col(c).cast("double"))
HiggsData.printSchema()
# Indexing all data.
HiggsData_index = HiggsData.select("*").withColumn("index", F.monotonically_increasing_id())
full_trainset = HiggsData_index.where("index <= 10499999").drop("index").cache()
full_testset = HiggsData_index.where("index > 10499999").drop("index").cache()

# Use the VectorAssembler tool to concatenate all the features in a vector
vecAssembler = VectorAssembler(inputCols = full_trainset.schema.names[:-1], outputCol = 'features') 
vecTrainingData = vecAssembler.transform(full_trainset)

# Evaluator for both the crossvalidation, and later for checking accuracy
evaluator1 = MulticlassClassificationEvaluator\
      (labelCol="labels", predictionCol="prediction", metricName="accuracy")
evaluator2 = BinaryClassificationEvaluator\
      (labelCol="labels", rawPredictionCol="prediction", metricName="areaUnderROC")
   
# Apply Random Forests over the subset of the dataset, combine stages into pipeline
rf = RandomForestClassifier(labelCol="labels", featuresCol="features", maxDepth=10, maxBins=20, numTrees = 10, featureSubsetStrategy = 'all', subsamplingRate = 0.9, seed=7)
stages = [vecAssembler, rf]
pipeline = Pipeline(stages=stages)

# Record the time before training model
t1 = datetime.now()
rfModel = pipeline.fit(full_trainset)
# Record the time after training model
t2 = datetime.now()
prediction_rf = rfModel.transform(full_testset)
accuracy_rf = evaluator1.evaluate(prediction_rf)
auc_rf = evaluator2.evaluate(prediction_rf)
print("Accuracy for best rf model = %g " % accuracy_rf)
print("AUC for best rf model = %g " % auc_rf)   
# Calculate training time
delta = t2 - t1
print("The training time of rf model is:", delta.total_seconds(),"seconds")
#Extract Feature importances
# .stages[-1] returns the last stage in the pipeline, which for our case is our classifier
# feature importance calculated by averaging the decrease in impurity over trees
featureImp = pd.DataFrame(
  list(zip(vecAssembler.getInputCols(), rfModel.stages[-1].featureImportances)),
  columns=["feature", "importance"])
print("The three most relevant features according to rf method")
print(featureImp.sort_values(by="importance", ascending=False).head(3))
   
# Apply Gradient boosint over the subset of the dataset, combine stages into pipeline
gbt = GBTClassifier(labelCol="labels", featuresCol="features", maxDepth=5, maxBins=20, featureSubsetStrategy='all', stepSize=0.1, subsamplingRate=0.5, seed=7)
stages = [vecAssembler, gbt]
pipeline = Pipeline(stages=stages)

# Record the time before training model
t3 = datetime.now()
gbtModel = pipeline.fit(full_trainset)
# Record the time after training model
t4 = datetime.now()
prediction_gbt = gbtModel.transform(full_testset)
accuracy_gbt = evaluator1.evaluate(prediction_gbt)
auc_gbt = evaluator2.evaluate(prediction_gbt)
print("Accuracy for best gbt model = %g " % accuracy_gbt)
print("AUC for best gbt model = %g " % auc_gbt)
# Calculate training time
delta = t4 - t3
print("The training time of gbt model is:", delta.total_seconds(),"seconds")
# Extract Feature importances
# .stages[-1] returns the last stage in the pipeline, which for our case is our classifier
# feature importance calculated by averaging the decrease in impurity over trees
featureImp = pd.DataFrame(
  list(zip(vecAssembler.getInputCols(), gbtModel.stages[-1].featureImportances)),
  columns=["feature", "importance"])
print("The three most relevant features according to gbt method")
print(featureImp.sort_values(by="importance", ascending=False).head(3))

# Apply neural network over the subset of the dataset, combine stages into pipeline
nn = MultilayerPerceptronClassifier(labelCol="labels", featuresCol="features", maxIter=100, blockSize=128, stepSize=0.003, layers=[28, 10, 2], seed=7)
stages = [vecAssembler, nn]
pipeline = Pipeline(stages=stages)

# Record the time before training model
t5 = datetime.now()
nnModel = pipeline.fit(full_trainset)
# Record the time after training model
t6 = datetime.now()
prediction_nn = nnModel.transform(full_testset)
accuracy_nn = evaluator1.evaluate(prediction_nn)
auc_nn = evaluator2.evaluate(prediction_nn)
print("Accuracy for best nn model = %g " % accuracy_nn)
print("AUC for best nn model = %g " % auc_nn)
# Calculate training time
delta = t6 - t5
print("The training time of nn model is:", delta.total_seconds(),"seconds")