from pyspark.sql import SparkSession
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import col
from pyspark.ml.feature import VectorAssembler
from pyspark.ml import Pipeline
from datetime import datetime
from pyspark.sql.functions import isnull, when, count, col
from pyspark.ml.stat import Correlation
from pyspark.ml.feature import StringIndexer, OneHotEncoder
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

spark = SparkSession.builder \
        .master("local[10]") \
        .appName("AS2Q2_1_test") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN") 

# Load dataset and preprocessing.
rawdata = spark.read.options(header='True').csv('../Data/train_set.csv')
rawdata = rawdata.cache()

# Q2-1a Deal with missing data
# Replace all '?' in the table to 'NaN'.
rawdata = rawdata.replace(['?'], None)

# Check the number of NaN in each column.
rawdata.select([count(when(isnull(c), c)).alias(c) for c in rawdata.columns]).show()
# Check the distinct column values of each column.
print(rawdata.select('Cat1').distinct().collect())
print(rawdata.select('Cat2').distinct().collect())
print(rawdata.select('Cat3').distinct().collect())
print(rawdata.select('Cat4').distinct().collect())
print(rawdata.select('Cat5').distinct().collect())
print(rawdata.select('Cat6').distinct().collect())
print(rawdata.select('Cat7').distinct().collect())
print(rawdata.select('Cat8').distinct().collect())
print(rawdata.select('Cat9').distinct().collect())
print(rawdata.select('Cat10').distinct().collect())
print(rawdata.select('Cat11').distinct().collect())
print(rawdata.select('Cat12').distinct().collect())
print(rawdata.select('ordcat').distinct().collect())
print(rawdata.select('nvcat').distinct().collect())

# Drop useless categorical and other columns.
rawdata = rawdata.select([c for c in rawdata.columns if c not in {'Cat1', 'Cat2', 'Cat4', \
                                                                    'Cat5', 'Cat7', 'Cat11', \
                                                                    'Cat12', 'OrdCat', 'NVCat', \
                                                                    'Row_ID', 'Household_ID', 'Vehicle', \
                                                                    'Calendar_Year', 'Model_Year', 'Blind_Make', \
                                                                    'Blind_Model', 'Blind_Submodel'}])

# Check the number of NaN in the rest of columns.
rawdata.select([count(when(isnull(c), c)).alias(c) for c in rawdata.columns]).show()
print(rawdata.count())
# Remove the rows with missing fields
rawdata = rawdata.na.drop()
print(rawdata.count())

# Partition the data into train(95%) and test(5%) sets.
trainset, testset = rawdata.randomSplit([0.95, 0.05], 7)
trainset = trainset.cache()
testset = testset.cache()

# Q2-1c Handle unbalanced training data
# Check how unbalanced the data is.
print("The number of instances where the claim amount is 0 before handling unbalanced data:", trainset.where("Claim_Amount == 0").count())
print("The number of instances where the claim amount is not 0 before handling unbalanced data:", trainset.where("Claim_Amount != 0").count())
# Balance the training data.
# In my trainset, the number of instance with zero claim amount is 12395573, the number of instance with non-zero claim amount is 87753, so the dataset is highly unbalanced.
# What I did is: under-sampling the data set containing the majority class label, and over-sampling the data set containing the minority class label, 
# so that the number of data with different labels is close, as a new training set.
claim_zero = trainset.where("Claim_Amount == 0")
claim_other = trainset.where("Claim_Amount != 0")
claim_other1 = claim_other
# Under-sampling the data set containing the majority class label.
claim_zero = claim_zero.sample(False, 0.5, 7)
# Over-sampling the data set containing the minority class label.
for i in range(0,140):
    claim_other_sample = claim_other1.sample(False, 0.5, i)
    claim_other = claim_other.union(claim_other_sample) 
# Union two dataset as the new trainset.
trainset_new = claim_zero.union(claim_other)
print("The number of instances where the claim amount is 0 after handling unbalanced data:", claim_zero.count())
print("The number of instances where the claim amount is not 0 after handling unbalanced data:", claim_other.count())
print("The number of instances in new training data:", trainset_new.count())
trainset_new.show(1)

# Explore continuous variable, study the correlation coefficient between the numerical attributes and the Claim_Amount.
trainset_new_without_cat = trainset_new.select([c for c in trainset_new.columns if c not in {'Cat3', 'Cat6', 'Cat8', 'Cat9', 'Cat10'}])
# Change data type from string to double for computing correlation coefficient later.
StringColumns = [x.name for x in trainset_new_without_cat.schema.fields if x.dataType == StringType()]
for c in StringColumns:
    trainset_new_without_cat = trainset_new_without_cat.withColumn(c, col(c).cast("double"))
# Convert to vector column first.
vector_col = "corr_features"
assembler = VectorAssembler(inputCols=trainset_new_without_cat.columns, outputCol=vector_col)
df_vector = assembler.transform(trainset_new_without_cat).select(vector_col)
# Get correlation matrix.
matrix = Correlation.corr(df_vector, vector_col)
# Get the result as a numpy array.
coor_mat = matrix.collect()[0]["pearson({})".format(vector_col)].values
# Show correlation coefficient between the numerical variables and the Claim_Amount.
print(coor_mat[-13:])
# Show numerical variables names for choosing.
print(trainset_new_without_cat.columns)

# Accroding to the correlation coefficient between the numerical variables and the Claim_Amount, drop 'Var8', 'NVVar2', 'NVVar3', 'NVVar4'.
# Use the rest of dataset as the trainset.
trainset_Q2 = trainset_new.select([c for c in trainset_new.columns if c not in {'Var8', 'NVVar2', 'NVVar3', 'NVVar4'}])

# Q2-1b Convert categorical values to a suitable representation
# I decide to convert categorical values through one-hot encoder.
categorical_columns= ['Cat3', 'Cat6', 'Cat8', 'Cat9', 'Cat10']
# The index of string vlaues multiple columns
indexers = [StringIndexer(inputCol=c, outputCol="{0}_indexed".format(c)) for c in categorical_columns]
encoders = [OneHotEncoder(dropLast=False,inputCol=indexer.getOutputCol(), outputCol="{0}_encoded".format(indexer.getOutputCol()))  for indexer in indexers]
# Vectorizing encoded values
assembler = VectorAssembler(inputCols=[encoder.getOutputCol() for encoder in encoders],outputCol="features")
pipeline = Pipeline(stages=indexers + encoders+[assembler])
model=pipeline.fit(trainset_Q2)
transformed = model.transform(trainset_Q2)
# Keep numerical attributes, vectorised categorical attributes and labels.
trainset_sub = transformed.select(['Var1', 'Var2', 'Var3', 'Var4', 'Var5', 'Var6', 'Var7', 'NVVar1', \
                        'Cat3_indexed_encoded', 'Cat6_indexed_encoded', 'Cat8_indexed_encoded', \
                        'Cat9_indexed_encoded', 'Cat10_indexed_encoded', 'Claim_Amount'])
trainset_final = trainset_sub.withColumnRenamed('Claim_Amount', 'labels')
# Change data type from string to double for model training later. 
StringColumns = [x.name for x in trainset_final.schema.fields if x.dataType == StringType()]
for c in StringColumns:
    trainset_final = trainset_final.withColumn(c, col(c).cast("double"))

trainset_final.show(1)
print(trainset_final.count())
# Same converting operation on testset.
model=pipeline.fit(testset)
transformed = model.transform(testset)
# Keep numerical attributes, vectorised categorical attributes and labels.
test_sub = transformed.select(['Var1', 'Var2', 'Var3', 'Var4', 'Var5', 'Var6', 'Var7', 'NVVar1', \
                        'Cat3_indexed_encoded', 'Cat6_indexed_encoded', 'Cat8_indexed_encoded', \
                        'Cat9_indexed_encoded', 'Cat10_indexed_encoded', 'Claim_Amount'])
testset_final = test_sub.withColumnRenamed('Claim_Amount', 'labels')
# Change data type from string to double for model training later. 
StringColumns = [x.name for x in testset_final.schema.fields if x.dataType == StringType()]
for c in StringColumns:
    testset_final = testset_final.withColumn(c, col(c).cast("double"))

testset_final.show(1)
print(testset_final.count())
# Save train and test data to disk
trainset_final.write.mode("overwrite").parquet('../Data/trainset_final.parquet')
testset_final.write.mode("overwrite").parquet('../Data/testset_final.parquet')