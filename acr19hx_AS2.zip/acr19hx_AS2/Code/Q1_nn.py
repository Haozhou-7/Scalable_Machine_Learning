from pyspark.sql import SparkSession
import numpy as np
import pandas as pd
import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql.functions import col
from pyspark.ml.feature import VectorAssembler
from pyspark.ml import Pipeline
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import MulticlassClassificationEvaluator, BinaryClassificationEvaluator
from pyspark.ml.classification import MultilayerPerceptronClassifier
from datetime import datetime
import json

spark = SparkSession.builder \
        .master("local[10]") \
        .appName("AS2Q1_nn") \
        .config("spark.local.dir","/fastdata/acr19hx") \
        .getOrCreate()
sc = spark.sparkContext
sc.setLogLevel("WARN") 

RawData = spark.read.text("../Data/HIGGS.csv.gz").cache() 

split_col = F.split(RawData['value'], ',')
HiggsData = RawData.withColumn('lepton_pT', split_col.getItem(1)) \
                     .withColumn('lepton_eta', split_col.getItem(2)) \
                     .withColumn('lepton_phi', split_col.getItem(3)) \
                     .withColumn('missing_energy_magnitude', split_col.getItem(4)) \
                     .withColumn('missing_energy_phi', split_col.getItem(5)) \
                     .withColumn('jet_1_pt', split_col.getItem(6)) \
                     .withColumn('jet_1_eta', split_col.getItem(7)) \
                     .withColumn('jet_1_phi', split_col.getItem(8)) \
                     .withColumn('jet_1_b-tag', split_col.getItem(9)) \
                     .withColumn('jet_2_pt', split_col.getItem(10)) \
                     .withColumn('jet_2_eta', split_col.getItem(11)) \
                     .withColumn('jet_2_phi', split_col.getItem(12)) \
                     .withColumn('jet_2_b-tag', split_col.getItem(13)) \
                     .withColumn('jet_3_pt', split_col.getItem(14)) \
                     .withColumn('jet_3_eta', split_col.getItem(15)) \
                     .withColumn('jet_3_phi', split_col.getItem(16)) \
                     .withColumn('jet_3_b-tag', split_col.getItem(17)) \
                     .withColumn('jet_4_pt', split_col.getItem(18)) \
                     .withColumn('jet_4_eta', split_col.getItem(19)) \
                     .withColumn('jet_4_phi', split_col.getItem(20)) \
                     .withColumn('jet_4_b-tag', split_col.getItem(21)) \
                     .withColumn('m_jj', split_col.getItem(22)) \
                     .withColumn('m_jjj', split_col.getItem(23)) \
                     .withColumn('m_lv', split_col.getItem(24)) \
                     .withColumn('m_jlv', split_col.getItem(25)) \
                     .withColumn('m_bb', split_col.getItem(26)) \
                     .withColumn('m_wbb', split_col.getItem(27)) \
                     .withColumn('m_wwbb', split_col.getItem(28)) \
                     .withColumn('labels', split_col.getItem(0)).drop("value").cache()

HiggsData.printSchema()
# Use the withColumn method for the dataframe to cast() each column to Double.
StringColumns = [x.name for x in HiggsData.schema.fields if x.dataType == StringType()]
for c in StringColumns:
    HiggsData = HiggsData.withColumn(c, col(c).cast("double"))
HiggsData.printSchema()
# Indexing all data.
HiggsData_index = HiggsData.select("*").withColumn("index", F.monotonically_increasing_id())
full_trainset = HiggsData_index.where("index <= 10499999").drop("index")
full_testset = HiggsData_index.where("index > 10499999").drop("index")
# Randomly choose 1% data from train set and test set for cross-validation.
a, sub_trainset = full_trainset.randomSplit([0.99, 0.01], 7)
b, sub_testset = full_testset.randomSplit([0.99, 0.01], 7)
sub_trainset = sub_trainset.cache() 
sub_testset = sub_testset.cache() 

# Use the VectorAssembler tool to concatenate all the features in a vector
vecAssembler = VectorAssembler(inputCols = sub_trainset.schema.names[:-1], outputCol = 'features') 
vecTrainingData = vecAssembler.transform(sub_trainset)

# Evaluator for both the crossvalidation, and later for checking accuracy
evaluator1 = MulticlassClassificationEvaluator\
      (labelCol="labels", predictionCol="prediction", metricName="accuracy")
evaluator2 = BinaryClassificationEvaluator\
      (labelCol="labels", rawPredictionCol="prediction", metricName="areaUnderROC")
      
# Apply neural network over the subset of the dataset, combine stages into pipeline
nn = MultilayerPerceptronClassifier(labelCol="labels", featuresCol="features", seed=7)
stages = [vecAssembler, nn]
pipeline = Pipeline(stages=stages)

# Create Paramater grid for crossvalidation. Each paramter is added with .addGrid()
paramGrid = ParamGridBuilder() \
    .addGrid(nn.maxIter, [50, 75, 100]) \
    .addGrid(nn.blockSize, [32, 64, 128]) \
    .addGrid(nn.stepSize, [0.003, 0.03, 0.3]) \
    .addGrid(nn.layers, [[28, 5, 2], [28, 10, 2], [28, 15, 2]]) \
    .build()
    
# Make Crossvalidator object, we use the same evaluator as for the previous exercise
crossval = CrossValidator(estimator=pipeline,
                          estimatorParamMaps=paramGrid,
                          evaluator=evaluator1,
                          numFolds=5)

# .fit() will run crossvalidation on all the folds and return the model with the best paramaters found
cvModel = crossval.fit(sub_trainset)
# Record performance of the best modal on small testset.
prediction = cvModel.transform(sub_testset)
accuracy = evaluator1.evaluate(prediction)
auc = evaluator2.evaluate(prediction)
print("Accuracy for best nn model  on small testset = %g " % accuracy)
print("AUC for best nn model  on small testset = %g " % auc)
# .bestModel() returns the model object in the crossvalidator. This object is a pipeline
# .stages[-1] returns the last stage in the pipeline, which for our case is our classifier
# .extractParamMap() returns a map with the parameters, which we turn into a dictionary 
paramDict = {param[0].name: param[1] for param in cvModel.bestModel.stages[-1].extractParamMap().items()}
# Here, we're converting the dictionary to a JSON object to make it easy to print. You can print it however you'd like
print(json.dumps(paramDict, indent = 4))